package bbsreply;

public class BbsReply {
	
	private int bbsID;				// �Խñ۹�ȣ
	private int replyID;			// �Խñ� ��۹�ȣ
	private String userID;			// ID
	private String replyDate;		// �Խó�¥
	private String replyContent;	// �Խó���
			
	public BbsReply(int bbsID, int replyID, String userID, String replyDate, String replyContent) {
		super();
		this.bbsID = bbsID;
		this.replyID = replyID;
		this.userID = userID;
		this.replyDate = replyDate;
		this.replyContent = replyContent;
	}
	
	public BbsReply() {
		// TODO Auto-generated constructor stub
	}
	
	public int getBbsID() {
		return bbsID;
	}
	public void setBbsID(int bbsID) {
		this.bbsID = bbsID;
	}
	public int getReplyID() {
		return replyID;
	}
	public void setReplyID(int replyID) {
		this.replyID = replyID;
	}
	public String getUserID() {
		return userID;
	}
	public void setUserID(String userID) {
		this.userID = userID;
	}
	public String getReplyDate() {
		return replyDate;
	}
	public void setReplyDate(String replyDate) {
		this.replyDate = replyDate;
	}
	public String getReplyContent() {
		return replyContent;
	}
	public void setReplyContent(String replyContent) {
		this.replyContent = replyContent;
	}
	
	
	
}
