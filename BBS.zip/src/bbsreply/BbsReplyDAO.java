package bbsreply;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;

import bbs.Bbs;
import bbsreply.BbsReply;

public class BbsReplyDAO {
	
	// dao : �����ͺ��̽� ���� ��ü�� ���ڷμ�
	// ���������� db���� ȸ������ �ҷ����ų� db�� ȸ������ ������
	private Connection conn; // connection:db�������ϰ� ���ִ� ��ü
	private ResultSet rs;
	
	// mysql ó���κ�
	public BbsReplyDAO() {
	// �����ڸ� ������ش�.
		try {
			String dbURL = "jdbc:mysql://localhost:3306/BBS?characterEncoding=UTF-8&serverTimezone=UTC";
			String dbID = "root";
			String dbPassword = "1234";
			Class.forName("com.mysql.jdbc.Driver");
			conn = DriverManager.getConnection(dbURL, dbID, dbPassword);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	public String getDate() {
		String SQL = "SELECT NOW()";
		try {
			PreparedStatement pstmt = conn.prepareStatement(SQL);
			rs = pstmt.executeQuery();
			if(rs.next()) {
				return rs.getString(1);
			}
		} catch (Exception e) {}
		return ""; // db ����
	}
	
	// ��� �迭
	public ArrayList<BbsReply> getList(int bbsID) {

		String SQL = "SELECT * FROM bbsreply WHERE bbsID = ? ORDER BY replyID ASC";
		ArrayList<BbsReply> replyList = new ArrayList<BbsReply>();
		try {
			
			PreparedStatement pstmt = conn.prepareStatement(SQL);
			pstmt.setInt(1, bbsID);
			rs = pstmt.executeQuery();
			
			while(rs.next()) {
				BbsReply bbsReply = new BbsReply(
						rs.getInt(1),
						rs.getInt(2),
						rs.getString(3),
						rs.getString(4),
						rs.getString(5)
						);
				replyList.add(bbsReply);
			}
//			if(rs != null) rs.close(); if(pstmt != null) pstmt.close();
//			if(conn != null) conn.close();
		} catch (Exception e) {
			e.printStackTrace();
		} 
		 
		return replyList;
	}
	
	// ��� �߰�
	public int write(int bbsID, String userID, String replyContent) {
		String SQL = "INSERT INTO bbsreply VALUES (?,?,?,?,?)";
		try {
			PreparedStatement pstmt = conn.prepareStatement(SQL);
			pstmt.setInt(1, bbsID);
			pstmt.setInt(2, getNext(bbsID));
			pstmt.setString(3, userID);
			pstmt.setString(4, getDate());
			pstmt.setString(5, replyContent);
						
			return pstmt.executeUpdate();
		} catch (Exception e) {}
		return -1; // db ����
	}

	// ��� ���� ��ȣ
	public int getNext(int bbsID) {
		String SQL = "select replyID FROM bbsreply where bbsID = ? order by replyID desc";
		try {
			PreparedStatement pstmt = conn.prepareStatement(SQL);
			pstmt.setInt(1, bbsID);
			rs = pstmt.executeQuery();
			if(rs.next()) {
				return rs.getInt(1) + 1;
			}
			return 1; // ù �Խù��� ���
		} catch (Exception e) {}
		return -1; // db ����
	}
	
	// ��� ���� ��������
	public BbsReply getBbsReply(int bbsID, int replyID) {
		String SQL = "SELECT * FROM bbsreply WHERE bbsID = ? AND replyID = ?";
		try {
			PreparedStatement pstmt = conn.prepareStatement(SQL);
			pstmt.setInt(1, bbsID);
			pstmt.setInt(2, replyID);
			rs = pstmt.executeQuery();
			if(rs.next()) {
				BbsReply bbsReply = new BbsReply();
				bbsReply.setBbsID(rs.getInt(1));
				bbsReply.setReplyID(rs.getInt(2));
				bbsReply.setUserID(rs.getString(3));
				bbsReply.setReplyDate(rs.getString(4));
				bbsReply.setReplyContent(rs.getString(5));
				return bbsReply;
			}
		} catch (Exception e) {}
		
		return null;

	}
	
	// ��� ����
	public int delete(int bbsID, int replyID) {
		String SQL = "delete from bbsreply where bbsID = ? AND replyID = ?";
		try {
			PreparedStatement pstmt = conn.prepareStatement(SQL);   
			pstmt.setInt(1, bbsID);
			pstmt.setInt(2, replyID);
			return pstmt.executeUpdate();
		}
		
		catch (Exception e) {
			e.printStackTrace();
		}
		return -1; // �����ͺ��̽� ����
	}
	
	
}
