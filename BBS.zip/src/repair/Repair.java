package repair;

public class Repair {
	
	private int repairBbsID;				// �����ȣ
	private String userID;			
	private String serviceDay;				// ����������
	private String serviceCenter;			// �����
	private String service;					// �����׸�
	private double serviceMoney;			// ��������ݾ�
	private double serviceTotalKm;			// ���� ��� �� ����Ÿ�
	
	
	public Repair(int repairBbsID, String userID, String serviceDay, String serviceCenter, String service,
			double serviceMoney, double serviceTotalKm) {
		super();
		this.repairBbsID = repairBbsID;
		this.userID = userID;
		this.serviceDay = serviceDay;
		this.serviceCenter = serviceCenter;
		this.service = service;
		this.serviceMoney = serviceMoney;
		this.serviceTotalKm = serviceTotalKm;
	}
	
	public Repair() {
		// TODO Auto-generated constructor stub
	}
	
	public int getRepairBbsID() {
		return repairBbsID;
	}
	public void setRepairBbsID(int repairBbsID) {
		this.repairBbsID = repairBbsID;
	}
	public String getUserID() {
		return userID;
	}
	public void setUserID(String userID) {
		this.userID = userID;
	}
	public String getServiceDay() {
		return serviceDay;
	}
	public void setServiceDay(String serviceDay) {
		this.serviceDay = serviceDay;
	}
	public String getServiceCenter() {
		return serviceCenter;
	}
	public void setServiceCenter(String serviceCenter) {
		this.serviceCenter = serviceCenter;
	}
	public String getService() {
		return service;
	}
	public void setService(String service) {
		this.service = service;
	}
	public double getServiceMoney() {
		return serviceMoney;
	}
	public void setServiceMoney(double serviceMoney) {
		this.serviceMoney = serviceMoney;
	}
	public double getServiceTotalKm() {
		return serviceTotalKm;
	}
	public void setServiceTotalKm(double serviceTotalKm) {
		this.serviceTotalKm = serviceTotalKm;
	}
	
	
	
	
}
