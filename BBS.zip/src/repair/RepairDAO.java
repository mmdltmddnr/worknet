package repair;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;


import repair.Repair;

public class RepairDAO {
	
	// dao : �����ͺ��̽� ���� ��ü�� ���ڷμ�
	// ���������� db���� ȸ������ �ҷ����ų� db�� ȸ������ ������
	private Connection conn; // connection:db�������ϰ� ���ִ� ��ü
	private PreparedStatement pstmt;
	private ResultSet rs;

	// mysql�� ������ �ִ� �κ�
	public RepairDAO() { // ������ ����ɶ����� �ڵ����� db������ �̷�� �� �� �ֵ�����
		try {
			// localhost:3306 ��Ʈ�� ��ǻ�ͼ�ġ�� mysql�ּ�
			String dbURL = "jdbc:mysql://localhost:3306/BBS?characterEncoding=UTF-8&serverTimezone=UTC";
		    String dbID = "root";
		    String dbPassword = "1234";
     	    Class.forName("com.mysql.cj.jdbc.Driver");
			conn = DriverManager.getConnection(dbURL, dbID, dbPassword);
		} catch (Exception e) {
			e.printStackTrace(); // ������ �������� ���
		}
	}
	
	public int addrepair(Repair repair) {
		String SQL = "insert into repair(repairBbsID,userID,serviceDay,serviceCenter,service,serviceMoney,serviceTotalKm) values(?,?,?,?,?,?,?)";
		try {
			pstmt = conn.prepareStatement(SQL);
			
			pstmt.setInt(1, getNext());
			pstmt.setString(2, repair.getUserID());
			pstmt.setString(3, repair.getServiceDay());
			pstmt.setString(4, repair.getServiceCenter());
			pstmt.setString(5, repair.getService());
			pstmt.setDouble(6, repair.getServiceMoney());
			pstmt.setDouble(7, repair.getServiceTotalKm());
			return pstmt.executeUpdate();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return -1; //db ����
	}
	
	// ����� bbs �迭
	public ArrayList<Repair> getList(String search, String userID) {
		
		String SQL = "SELECT * FROM repair WHERE userID LIKE ? AND CONCAT(serviceDay,serviceCenter,service,serviceMoney,serviceTotalKm) LIKE ? ORDER BY serviceDay DESC";
		ArrayList<Repair> list = new ArrayList<Repair>();
		try {
			PreparedStatement pstmt = conn.prepareStatement(SQL);
			pstmt.setString(1, userID);
			pstmt.setString(2, "%" + search + "%");
			rs = pstmt.executeQuery();
			while(rs.next()) {
				Repair repair = new Repair();
				repair.setRepairBbsID(rs.getInt(1));
				repair.setUserID(rs.getString(2));
				repair.setServiceDay(rs.getString(3));
				repair.setServiceCenter(rs.getString(4));
				repair.setService(rs.getString(5));
				repair.setServiceMoney(rs.getDouble(6));
				repair.setServiceTotalKm(rs.getDouble(7));
				
				list.add(repair);
			}
		} catch (Exception e) {}
		return list;
	}
	
	// Repair ��� �� ����Ÿ��� ���� ū ��ü ��
	public Repair getMaxRepair(String userID) {
		String SQL = "SELECT userID, max(ServiceTotalKm) as serviceTotalKm FROM repair WHERE userID = ?";
		try {
			PreparedStatement pstmt = conn.prepareStatement(SQL);
			pstmt.setString(1, userID);
			rs = pstmt.executeQuery();
			if(rs.next()) {
				Repair repair = new Repair();
				repair.setUserID(rs.getString("userID"));
				repair.setServiceTotalKm(rs.getDouble("serviceTotalKm"));
				
				return repair;								  
			}
		} catch (Exception e) {}
		
		return null;

	}
	
	// RepairƯ�� ��� ���� ��������
	public Repair getRepair(int repairBbsID) {
		String SQL = "SELECT * FROM repair WHERE repairBbsID = ?";
		try {
			PreparedStatement pstmt = conn.prepareStatement(SQL);
			pstmt.setInt(1, repairBbsID);
			rs = pstmt.executeQuery();
			if(rs.next()) {
				Repair repair = new Repair();
				repair.setRepairBbsID(rs.getInt(1));
				repair.setUserID(rs.getString(2));
				repair.setServiceDay(rs.getString(3));
				repair.setServiceCenter(rs.getString(4));
				repair.setService(rs.getString(5));
				repair.setServiceMoney(rs.getDouble(6));
				repair.setServiceTotalKm(rs.getDouble(7));
				
				return repair;								  
			}
		} catch (Exception e) {}
		
		return null;

	}
	
	public int update(String serviceDay, String serviceCenter, String service, Double serviceMoney, Double serviceTotalKm, int repairBbsID) {

		String SQL = "update repair set serviceDay = ?, serviceCenter = ?, service = ?, serviceMoney = ?, serviceTotalKm = ? where repairBbsID = ?";
		try {
			PreparedStatement pstmt = conn.prepareStatement(SQL);
			pstmt.setString(1, serviceDay);
			pstmt.setString(2, serviceCenter);
			pstmt.setString(3, service);
			pstmt.setDouble(4, serviceMoney);
			pstmt.setDouble(5, serviceTotalKm);
			pstmt.setInt(6, repairBbsID);
			
			return pstmt.executeUpdate();

		} catch (Exception e) {
			e.printStackTrace();
		}
		return -1; // �����ͺ��̽� ����
	}
	
	//�����Ϲ�ȣ 
	public int getNext() {
		String SQL = "SELECT repairBbsID FROM repair ORDER BY repairBbsID DESC";
		try {
			PreparedStatement pstmt = conn.prepareStatement(SQL);
			
			rs = pstmt.executeQuery();
			if(rs.next()) {
				return rs.getInt(1) + 1;
			}
			return 1; // ù �Խù��� ���
		} catch (Exception e) {}
		return -1; // db ����
	}
	
	//���� �� ����ݾ�
	public Double getTotalMoney() {
		String SQL = "select sum(serviceMoney) from repair";
		try {
			PreparedStatement pstmt = conn.prepareStatement(SQL);
			rs = pstmt.executeQuery();
			if(rs.next()) {
				return rs.getDouble(1);
			}
			return 0.0;

		} catch (Exception e) {
			e.printStackTrace();
		}
		return -1.0; // �����ͺ��̽� ����
	}
	
	// Ư�� �������� ��������
	public Repair getBbs(int repairBbsID) {
		String SQL = "SELECT * FROM repair WHERE repairBbsID = ?";
		try {
			PreparedStatement pstmt = conn.prepareStatement(SQL);
			pstmt.setInt(1, repairBbsID);
			rs = pstmt.executeQuery();
			if(rs.next()) {
				Repair repair = new Repair();
				repair.setRepairBbsID(rs.getInt(1));
				repair.setUserID(rs.getString(2));
				repair.setServiceDay(rs.getString(3));
				repair.setServiceCenter(rs.getString(4));
				repair.setService(rs.getString(5));
				repair.setServiceMoney(rs.getDouble(6));
				repair.setServiceTotalKm(rs.getDouble(7));
				return repair;
			}
		} catch (Exception e) {}
		
		return null;

	}
	
	//���� �Լ�
	public int delete(int repairBbsID) {
		String SQL = "delete from repair where repairBbsID = ?";
		try {
			PreparedStatement pstmt = conn.prepareStatement(SQL);   
			pstmt.setInt(1, repairBbsID);
			return pstmt.executeUpdate();
		}
		
		catch (Exception e) {
			e.printStackTrace();
		}
		return -1; // �����ͺ��̽� ����
	}
	
}
