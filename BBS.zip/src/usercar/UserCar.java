package usercar;

public class UserCar {

	private String userID;				
	private String userCarModel;
	private String userCarName;// ����
	private int userCarType;			// �⸧ Ÿ��
	private double userCarTotalKmNow;		// ������Ÿ� - ����
	private double userCarTotalKmOld;		// ������Ÿ� - ����
	private double userCarGasMoney;		// ������
	private String userCarDay;			// ����������
	private double userCarMileage;		// ����
	
	//�Ű����� �õ�ٲ�
	public UserCar(String userID, String userCarModel, String userCarName, int userCarType, double userCarTotalKmNow, double userCarTotalKmOld, 
			double userCarGasMoney, String userCarDay, double userCarMileage) {
		super();
		this.userID = userID;
		this.userCarModel = userCarModel;
		this.userCarType = userCarType;
		this.userCarTotalKmNow = userCarTotalKmNow;
		//�ٲ�
		this.userCarTotalKmOld = userCarTotalKmOld;
		this.userCarGasMoney = userCarGasMoney;
		this.userCarDay = userCarDay;
		this.userCarMileage = userCarMileage;
	}
	public UserCar() {
		// TODO Auto-generated constructor stub
	}
	
	public String getUserID() {
		return userID;
	}
	public void setUserID(String userID) {
		this.userID = userID;
	}
	public String getUserCarModel() {
		return userCarModel;
	}
	public void setUserCarModel(String userCarModel) {
		this.userCarModel = userCarModel;
	}
	
	public String getUserCarName() {
		return userCarName;
	}
	public void setUserCarName(String userCarName) {
		this.userCarName = userCarName;
	}
	public int getUserCarType() {
		return userCarType;
	}
	public void setUserCarType(int userCarType) {
		this.userCarType = userCarType;
	}
	public double getUserCarTotalKmNow() {
		return userCarTotalKmNow;
	}
	public void setUserCarTotalKmNow(double userCarTotalKmNow) {
		this.userCarTotalKmNow = userCarTotalKmNow;
	}
	public double getUserCarTotalKmOld() {
		return userCarTotalKmOld;
	}
	public void setUserCarTotalKmOld(double userCarTotalKmOld) {
		this.userCarTotalKmOld = userCarTotalKmOld;
	}
	public double getUserCarGasMoney() {
		return userCarGasMoney;
	}
	public void setUserCarGasMoney(double userCarGasMoney) {
		this.userCarGasMoney = userCarGasMoney;
	}
	public String getUserCarDay() {
		return userCarDay;
	}
	public void setUserCarDay(String userCarDay) {
		this.userCarDay = userCarDay;
	}
	public double getUserCarMileage() {
		return userCarMileage;
	}
	public void setUserCarMileage(double userCarMileage) {
		this.userCarMileage = userCarMileage;
	}

	
	
}
